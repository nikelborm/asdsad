﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using F = System.Windows.Forms;
using D = System.Drawing;

namespace Gaben
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const string FIRST_STEP_HEADER = "Генерация случайного массива в процессе";
        private const string SECOND_STEP_HEADER = "Сортировка массива в процессе";
        Random rnd = new Random();
        private int[] getArrayWithExactLengthContainsRandomIntNumbers( int length )
        {
            int[] fillableArrayOfIntNumbers = new int[ length ];
            for ( int i = 0; i < length; i++ )
            {
                fillableArrayOfIntNumbers[ i ] = rnd.Next( 0, 10000 );
            }
            return fillableArrayOfIntNumbers;
        }

        private void sortArrayOfIntNumbers( int[] arrayOfIntNumbers )
        {
            int temp;
            for ( int i = 0; i < arrayOfIntNumbers.Length; i++ )
            {
                for ( int j = i + 1; j < arrayOfIntNumbers.Length; j++ )
                {
                    if ( arrayOfIntNumbers[ i ] < arrayOfIntNumbers[ j ] )
                    {
                        temp = arrayOfIntNumbers[ i ];
                        arrayOfIntNumbers[ i ] = arrayOfIntNumbers[ j ];
                        arrayOfIntNumbers[ j ] = temp;
                    }
                }
            }
        }

        private string getStringContainsElementsFromIntArray( int[] inputArrayWithIntNumbers )
        {
            String[] fillableArrayOfStrings = new String[ inputArrayWithIntNumbers.Length ];
            for ( int i = 0; i < inputArrayWithIntNumbers.Length; i++ )
            {
                fillableArrayOfStrings[ i ] = inputArrayWithIntNumbers[ i ].ToString();
            }
            return String.Join( " ", fillableArrayOfStrings );
        }

        private void executeTask( int manipulationArrayLength ) {
            LabelContainsUnsortedArray.Content = FIRST_STEP_HEADER;
            int[] superArr = getArrayWithExactLengthContainsRandomIntNumbers( manipulationArrayLength );
            LabelContainsUnsortedArray.Content = "Несортированный массив: " + getStringContainsElementsFromIntArray( superArr );
            LabelContainsSortedArray.Content = SECOND_STEP_HEADER;
            sortArrayOfIntNumbers( superArr );
            LabelContainsSortedArray.Content = "Отсортированный массив: " + getStringContainsElementsFromIntArray( superArr );
            LabelContainsMaxNumber.Content = "Максимальное число: " + superArr[ 0 ].ToString();
        }

        public MainWindow()
        {
            InitializeComponent();
            executeTask( 10 );
        }

        private void RegenerateArrayButtonClickHandler( object sender, RoutedEventArgs e )
        {
            executeTask( 10 );
        }
    }
}
